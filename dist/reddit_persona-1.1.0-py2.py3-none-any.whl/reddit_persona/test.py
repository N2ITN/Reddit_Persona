import reddit_persona as rp

testme = rp.go('GovSchwarzenegger')

print(testme)
