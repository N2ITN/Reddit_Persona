import reddit_persona as rp
import sys


rp.go(sys.argv[1])